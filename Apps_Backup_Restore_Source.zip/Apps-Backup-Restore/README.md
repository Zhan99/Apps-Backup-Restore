# Apps Backup Restore

**Developer:** Shahriar Rahman  
**Brand:** SR Creation Farm  
**YouTube:** [@SRCreation-farm](https://www.youtube.com/@SRCreation-farm)  
**Facebook:** [SR Creation Farm](https://fb.com/srcreation.farm)

## Overview
**Apps Backup Restore** is a clean, offline, advertisement-free Android utility for backing up and restoring installed applications—supporting both standard `.apk` backups (preserving original signatures and File Manager icons) and multi-part Split APK bundles (`.apks` installed via `PackageInstaller.Session`).

## Folder Structure Created in User-Selected Directory
```text
App Backup/
├── AppName.apk
└── Split backups/
    └── SplitAppName.apks
```

## GitHub Actions Build Instructions
1. Upload `Apps_Backup_Restore_Source.zip` to the root of your GitHub repository.
2. Upload `build.yml` to `.github/workflows/build.yml`.
3. Open the **Actions** tab in GitHub and trigger **Build Android APK & Run Lint** (or push to `main`).
4. Download the compiled APK from **Artifacts -> Apps-Backup-Restore-Debug-APK**.
