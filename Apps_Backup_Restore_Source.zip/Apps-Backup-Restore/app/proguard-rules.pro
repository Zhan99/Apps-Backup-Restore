# Keep model classes
-keep class com.srcreationfarm.appsbackuprestore.model.** { *; }
