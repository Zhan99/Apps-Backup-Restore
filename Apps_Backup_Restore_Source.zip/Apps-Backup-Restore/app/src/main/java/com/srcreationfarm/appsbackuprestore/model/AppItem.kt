package com.srcreationfarm.appsbackuprestore.model

import android.graphics.drawable.Drawable
import android.net.Uri

data class AppItem(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sizeBytes: Long,
    val timestamp: Long,
    val icon: Drawable?,
    val isSystemApp: Boolean = false,
    val isSplitApk: Boolean = false,
    val baseApkPath: String? = null,
    val splitApkPaths: List<String> = emptyList(),
    var isBackedUp: Boolean = false,
    val isArchivedItem: Boolean = false,
    val archiveApkUri: Uri? = null,
    val archiveApkFileName: String? = null,
    val archiveSplitApksUri: Uri? = null,
    var isSelected: Boolean = false
)
