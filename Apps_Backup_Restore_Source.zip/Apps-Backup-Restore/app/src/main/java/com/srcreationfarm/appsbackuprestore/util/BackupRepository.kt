package com.srcreationfarm.appsbackuprestore.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.srcreationfarm.appsbackuprestore.model.AppItem
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BackupRepository(private val context: Context) {

    companion object {
        const val ROOT_BACKUP_DIR = "App Backup"
        const val SPLIT_SUBDIR = "Split backups"
    }

    fun hasValidTreePermission(treeUri: Uri?): Boolean {
        if (treeUri == null) return false
        val persisted = context.contentResolver.persistedUriPermissions
        val hasPerm = persisted.any {
            it.uri == treeUri && it.isReadPermission && it.isWritePermission
        }
        if (!hasPerm) return false
        val doc = DocumentFile.fromTreeUri(context, treeUri)
        return doc != null && doc.exists() && doc.canWrite()
    }

    private fun getOrCreateAppBackupDir(treeUri: Uri): DocumentFile? {
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        if (!rootDoc.exists() || !rootDoc.canWrite()) return null
        return rootDoc.findFile(ROOT_BACKUP_DIR)?.takeIf { it.isDirectory }
            ?: rootDoc.createDirectory(ROOT_BACKUP_DIR)
    }

    private fun getOrCreateSplitBackupDir(appBackupDir: DocumentFile): DocumentFile? {
        return appBackupDir.findFile(SPLIT_SUBDIR)?.takeIf { it.isDirectory }
            ?: appBackupDir.createDirectory(SPLIT_SUBDIR)
    }

    fun loadInstalledApps(includeSystem: Boolean, treeUri: Uri?): List<AppItem> {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }

        val existingBackupFiles = mutableSetOf<String>()
        if (hasValidTreePermission(treeUri) && treeUri != null) {
            val backupDir = DocumentFile.fromTreeUri(context, treeUri)?.findFile(ROOT_BACKUP_DIR)
            backupDir?.listFiles()?.forEach { file ->
                val name = file.name
                if (file.isFile && name != null && name.endsWith(".apk", ignoreCase = true)) {
                    existingBackupFiles.add(name.lowercase())
                }
            }
        }

        val result = mutableListOf<AppItem>()
        for (pkgInfo in packages) {
            val appInfo = pkgInfo.applicationInfo ?: continue
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!includeSystem && isSystem) continue

            val basePath = appInfo.publicSourceDir ?: appInfo.sourceDir ?: continue
            val baseFile = File(basePath)
            if (!baseFile.exists()) continue

            val splits = appInfo.splitPublicSourceDirs?.toList()
                ?: appInfo.splitSourceDirs?.toList()
                ?: emptyList()
            val validSplits = splits.filter { File(it).exists() }

            var totalSize = baseFile.length()
            for (sp in validSplits) {
                totalSize += File(sp).length()
            }

            val label = try {
                pm.getApplicationLabel(appInfo).toString()
            } catch (_: Exception) {
                pkgInfo.packageName
            }

            val versionName = pkgInfo.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }

            val icon = try {
                pm.getApplicationIcon(appInfo)
            } catch (_: Exception) {
                null
            }

            val sanitizedBase = FormatUtils.sanitizeFileName(label).lowercase()
            val isBackedUp = existingBackupFiles.any {
                it == "$sanitizedBase.apk" || it.startsWith("${sanitizedBase}_v")
            }

            result.add(
                AppItem(
                    appName = label,
                    packageName = pkgInfo.packageName,
                    versionName = versionName,
                    versionCode = versionCode,
                    sizeBytes = totalSize,
                    timestamp = pkgInfo.lastUpdateTime,
                    icon = icon,
                    isSystemApp = isSystem,
                    isSplitApk = validSplits.isNotEmpty(),
                    baseApkPath = basePath,
                    splitApkPaths = validSplits,
                    isBackedUp = isBackedUp
                )
            )
        }
        return result
    }

    fun loadArchivedBackups(treeUri: Uri?): List<AppItem> {
        if (!hasValidTreePermission(treeUri) || treeUri == null) return emptyList()
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
        val appBackupDir = rootDoc.findFile(ROOT_BACKUP_DIR)?.takeIf { it.isDirectory } ?: return emptyList()
        val splitDir = appBackupDir.findFile(SPLIT_SUBDIR)?.takeIf { it.isDirectory }

        val splitMap = mutableMapOf<String, DocumentFile>()
        splitDir?.listFiles()?.forEach { file ->
            val n = file.name
            if (file.isFile && n != null && n.endsWith(".apks", ignoreCase = true)) {
                val stem = n.substringBeforeLast(".")
                splitMap[stem.lowercase()] = file
            }
        }

        val pm = context.packageManager
        val items = mutableListOf<AppItem>()
        val seenStems = mutableSetOf<String>()

        appBackupDir.listFiles().forEach { file ->
            val fileName = file.name ?: return@forEach
            if (!file.isFile || !fileName.endsWith(".apk", ignoreCase = true)) return@forEach

            val stem = fileName.substringBeforeLast(".")
            seenStems.add(stem.lowercase())
            val matchingSplit = splitMap[stem.lowercase()]

            val parsed = inspectArchivedApk(pm, file, matchingSplit)
            items.add(parsed)
        }

        splitMap.forEach { (stemLower, apksFile) ->
            if (!seenStems.contains(stemLower)) {
                val apksName = apksFile.name ?: "Backup.apks"
                val displayName = apksName.substringBeforeLast(".")
                items.add(
                    AppItem(
                        appName = displayName,
                        packageName = "Split Archive ($apksName)",
                        versionName = "Archive",
                        versionCode = 0L,
                        sizeBytes = apksFile.length(),
                        timestamp = apksFile.lastModified(),
                        icon = context.getDrawable(android.R.drawable.sym_def_app_icon),
                        isSplitApk = true,
                        isBackedUp = true,
                        isArchivedItem = true,
                        archiveApkUri = null,
                        archiveApkFileName = apksName,
                        archiveSplitApksUri = apksFile.uri
                    )
                )
            }
        }

        return items
    }

    private fun inspectArchivedApk(
        pm: PackageManager,
        apkDoc: DocumentFile,
        splitDoc: DocumentFile?
    ): AppItem {
        val fileName = apkDoc.name ?: "App.apk"
        val fallbackName = fileName.substringBeforeLast(".")
        val tempFile = File(context.cacheDir, "inspect_temp.apk")

        var appName = fallbackName
        var pkgName = fileName
        var verName = "1.0"
        var verCode = 0L
        var icon = context.getDrawable(android.R.drawable.sym_def_app_icon)

        try {
            context.contentResolver.openInputStream(apkDoc.uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }
            val pkgInfo: PackageInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(tempFile.absolutePath, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(tempFile.absolutePath, 0)
            }
            if (pkgInfo != null) {
                pkgName = pkgInfo.packageName
                verName = pkgInfo.versionName ?: "1.0"
                verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo.versionCode.toLong()
                }
                pkgInfo.applicationInfo?.let { ai ->
                    ai.sourceDir = tempFile.absolutePath
                    ai.publicSourceDir = tempFile.absolutePath
                    appName = pm.getApplicationLabel(ai).toString()
                    icon = pm.getApplicationIcon(ai)
                }
            }
        } catch (_: Exception) {
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }

        val totalSize = (splitDoc?.length() ?: 0L).let { splitSize ->
            if (splitSize > 0L) splitSize else apkDoc.length()
        }

        return AppItem(
            appName = appName,
            packageName = pkgName,
            versionName = verName,
            versionCode = verCode,
            sizeBytes = totalSize,
            timestamp = apkDoc.lastModified(),
            icon = icon,
            isSplitApk = splitDoc != null,
            isBackedUp = true,
            isArchivedItem = true,
            archiveApkUri = apkDoc.uri,
            archiveApkFileName = fileName,
            archiveSplitApksUri = splitDoc?.uri
        )
    }

    fun backupSingleApp(
        app: AppItem,
        treeUri: Uri,
        keepOldVersion: Boolean
    ): Result<String> {
        return try {
            val basePath = app.baseApkPath ?: return Result.failure(Exception("Base APK not found"))
            val baseFile = File(basePath)
            if (!baseFile.exists()) return Result.failure(Exception("Base APK file missing on disk"))

            val appBackupDir = getOrCreateAppBackupDir(treeUri)
                ?: return Result.failure(Exception("Cannot access or create App Backup folder"))

            val sanitizedAppName = FormatUtils.sanitizeFileName(app.appName)
            val sanitizedVer = FormatUtils.sanitizeFileName(app.versionName)
            val baseStem = if (keepOldVersion) {
                "${sanitizedAppName}_v${sanitizedVer}_${app.versionCode}"
            } else {
                sanitizedAppName
            }

            val apkFileName = "$baseStem.apk"
            val tempApkName = ".tmp_${System.currentTimeMillis()}_$apkFileName"

            val tempDoc = appBackupDir.createFile("application/vnd.android.package-archive", tempApkName)
                ?: return Result.failure(Exception("Failed to create temporary backup file"))

            try {
                FileInputStream(baseFile).use { input ->
                    context.contentResolver.openOutputStream(tempDoc.uri)?.use { output ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    } ?: throw Exception("Unable to open output stream")
                }
            } catch (e: Exception) {
                tempDoc.delete()
                return Result.failure(e)
            }

            appBackupDir.findFile(apkFileName)?.delete()

            val renamed = tempDoc.renameTo(apkFileName)
            if (!renamed) {
                val finalDoc = appBackupDir.createFile("application/vnd.android.package-archive", apkFileName)
                if (finalDoc != null) {
                    context.contentResolver.openInputStream(tempDoc.uri)?.use { inp ->
                        context.contentResolver.openOutputStream(finalDoc.uri)?.use { out ->
                            inp.copyTo(out, bufferSize = 64 * 1024)
                        }
                    }
                    tempDoc.delete()
                }
            }

            if (app.isSplitApk && app.splitApkPaths.isNotEmpty()) {
                val splitDir = getOrCreateSplitBackupDir(appBackupDir)
                    ?: return Result.failure(Exception("Cannot create Split backups subfolder"))
                val apksFileName = "$baseStem.apks"
                val tempApksName = ".tmp_${System.currentTimeMillis()}_$apksFileName"
                val tempSplitDoc = splitDir.createFile("application/octet-stream", tempApksName)
                    ?: return Result.failure(Exception("Failed to create split archive"))

                try {
                    context.contentResolver.openOutputStream(tempSplitDoc.uri)?.use { rawOut ->
                        ZipOutputStream(BufferedOutputStream(rawOut)).use { zipOut ->
                            zipOut.setMethod(ZipOutputStream.STORED)

                            val allPaths = listOf(basePath) + app.splitApkPaths
                            for (apkPath in allPaths) {
                                val f = File(apkPath)
                                if (!f.exists()) continue
                                val entryName = if (apkPath == basePath) "base.apk" else f.name
                                val crc = computeCrc32(f)
                                val entry = ZipEntry(entryName).apply {
                                    method = ZipEntry.STORED
                                    size = f.length()
                                    compressedSize = f.length()
                                    this.crc = crc
                                }
                                zipOut.putNextEntry(entry)
                                BufferedInputStream(FileInputStream(f)).use { bis ->
                                    bis.copyTo(zipOut, bufferSize = 64 * 1024)
                                }
                                zipOut.closeEntry()
                            }

                            val metaJson = JSONObject().apply {
                                put("appName", app.appName)
                                put("packageName", app.packageName)
                                put("versionName", app.versionName)
                                put("versionCode", app.versionCode)
                                put("timestamp", System.currentTimeMillis())
                            }.toString(2).toByteArray(Charsets.UTF_8)

                            val metaCrc = java.util.zip.CRC32().apply { update(metaJson) }.value
                            val metaEntry = ZipEntry("metadata.json").apply {
                                method = ZipEntry.STORED
                                size = metaJson.size.toLong()
                                compressedSize = metaJson.size.toLong()
                                crc = metaCrc
                            }
                            zipOut.putNextEntry(metaEntry)
                            zipOut.write(metaJson)
                            zipOut.closeEntry()
                        }
                    } ?: throw Exception("Failed writing split archive")
                } catch (e: Exception) {
                    tempSplitDoc.delete()
                    return Result.failure(e)
                }

                splitDir.findFile(apksFileName)?.delete()
                val splitRenamed = tempSplitDoc.renameTo(apksFileName)
                if (!splitRenamed) {
                    val finalSplit = splitDir.createFile("application/octet-stream", apksFileName)
                    if (finalSplit != null) {
                        context.contentResolver.openInputStream(tempSplitDoc.uri)?.use { inp ->
                            context.contentResolver.openOutputStream(finalSplit.uri)?.use { out ->
                                inp.copyTo(out, bufferSize = 64 * 1024)
                            }
                        }
                        tempSplitDoc.delete()
                    }
                }
            }

            Result.success(apkFileName)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun computeCrc32(file: File): Long {
        val crc = java.util.zip.CRC32()
        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(64 * 1024)
            var bytesRead: Int
            while (input.read(buffer).also { bytesRead = it } != -1) {
                crc.update(buffer, 0, bytesRead)
            }
        }
        return crc.value
    }

    fun deleteArchivedItem(item: AppItem): Boolean {
        var deletedAny = false
        item.archiveApkUri?.let { uri ->
            val doc = DocumentFile.fromSingleUri(context, uri)
            if (doc != null && doc.delete()) deletedAny = true
        }
        item.archiveSplitApksUri?.let { uri ->
            val doc = DocumentFile.fromSingleUri(context, uri)
            if (doc != null && doc.delete()) deletedAny = true
        }
        return deletedAny
    }

    fun buildShareIntent(items: List<AppItem>): Intent? {
        val shareDir = File(context.cacheDir, "shared_apks")
        if (shareDir.exists()) {
            shareDir.listFiles()?.forEach { it.delete() }
        } else {
            shareDir.mkdirs()
        }

        val uris = ArrayList<Uri>()
        for (item in items) {
            val sanitized = FormatUtils.sanitizeFileName(item.appName)
            if (!item.isArchivedItem) {
                val basePath = item.baseApkPath ?: continue
                val src = File(basePath)
                if (!src.exists()) continue
                val dest = File(shareDir, "$sanitized.apk")
                src.copyTo(dest, overwrite = true)
                uris.add(
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        dest
                    )
                )
            } else {
                val sourceUri = item.archiveSplitApksUri ?: item.archiveApkUri ?: continue
                val ext = if (item.archiveSplitApksUri != null) "apks" else "apk"
                val dest = File(shareDir, "$sanitized.$ext")
                try {
                    context.contentResolver.openInputStream(sourceUri)?.use { inp ->
                        FileOutputStream(dest).use { out ->
                            inp.copyTo(out, bufferSize = 64 * 1024)
                        }
                    }
                    if (dest.exists() && dest.length() > 0L) {
                        uris.add(
                            FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.fileprovider",
                                dest
                            )
                        )
                    }
                } catch (_: Exception) {
                }
            }
        }

        if (uris.isEmpty()) return null

        return if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uris[0])
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }
}
