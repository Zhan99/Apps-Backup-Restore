package com.srcreationfarm.appsbackuprestore.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FormatUtils {
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var size = bytes.toDouble()
        var unitIdx = 0
        while (size >= 1024.0 && unitIdx < units.size - 1) {
            size /= 1024.0
            unitIdx++
        }
        return String.format(Locale.US, "%.2f %s", size, units[unitIdx])
    }

    fun formatDate(timestamp: Long): String {
        if (timestamp <= 0L) return "Unknown"
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun sanitizeFileName(rawName: String): String {
        val cleaned = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (cleaned.isEmpty()) "AppBackup" else cleaned
    }
}
