package com.srcreationfarm.appsbackuprestore

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.tabs.TabLayout
import com.srcreationfarm.appsbackuprestore.adapter.AppListAdapter
import com.srcreationfarm.appsbackuprestore.databinding.ActivityMainBinding
import com.srcreationfarm.appsbackuprestore.model.AppItem
import com.srcreationfarm.appsbackuprestore.model.SortOption
import com.srcreationfarm.appsbackuprestore.util.ApkInstallerHelper
import com.srcreationfarm.appsbackuprestore.util.BackupRepository
import com.srcreationfarm.appsbackuprestore.util.PrefsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager
    private lateinit var repository: BackupRepository
    private lateinit var adapter: AppListAdapter

    private var currentTab = 0
    private var allItems = listOf<AppItem>()
    private var currentQuery = ""

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                contentResolver.takePersistableUriPermission(uri, takeFlags)
                prefs.backupTreeUri = uri
                updateFolderBanner()
                refreshData()
                Toast.makeText(this, "Backup folder saved!", Toast.LENGTH_SHORT).show()
            } catch (e: SecurityException) {
                Toast.makeText(
                    this,
                    "Permission error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private val uninstallLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshData()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = PrefsManager(this)
        AppCompatDelegate.setDefaultNightMode(prefs.themeMode)

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = BackupRepository(this)
        setSupportActionBar(binding.toolbar)

        setupRecyclerView()
        setupTabs()
        setupButtons()
        updateFolderBanner()
        refreshData()
    }

    private fun setupRecyclerView() {
        adapter = AppListAdapter(
            onSelectionChanged = { updateSummaryBar() },
            onItemLongClick = { item -> showSingleItemActionDialog(item) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener {
            refreshData()
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentTab = tab?.position ?: 0
                if (currentTab == 0) {
                    binding.bottomBarInstalled.visibility = View.VISIBLE
                    binding.bottomBarArchived.visibility = View.GONE
                } else {
                    binding.bottomBarInstalled.visibility = View.GONE
                    binding.bottomBarArchived.visibility = View.VISIBLE
                }
                refreshData()
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupButtons() {
        binding.btnChooseFolder.setOnClickListener {
            folderPickerLauncher.launch(prefs.backupTreeUri)
        }

        binding.btnBatchBackup.setOnClickListener {
            val selected = adapter.getSelectedItems()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select at least one app to backup", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            performBatchBackup(selected)
        }

        binding.btnShareInstalled.setOnClickListener {
            val selected = adapter.getSelectedItems()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select apps to share", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            shareItems(selected)
        }

        binding.btnUninstall.setOnClickListener {
            val selected = adapter.getSelectedItems()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select apps to uninstall", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            uninstallItems(selected)
        }

        binding.btnBatchRestore.setOnClickListener {
            val selected = adapter.getSelectedItems()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select backups to restore", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            performRestore(selected)
        }

        binding.btnShareArchived.setOnClickListener {
            val selected = adapter.getSelectedItems()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select backups to share", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            shareItems(selected)
        }

        binding.btnDeleteBackup.setOnClickListener {
            val selected = adapter.getSelectedItems()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select backups to delete", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            confirmDeleteBackups(selected)
        }
    }

    private fun updateFolderBanner() {
        val uri = prefs.backupTreeUri
        if (repository.hasValidTreePermission(uri) && uri != null) {
            val doc = DocumentFile.fromTreeUri(this, uri)
            val folderName = doc?.name ?: uri.lastPathSegment ?: "Selected Folder"
            binding.tvFolderStatus.text = "Folder: $folderName / App Backup"
        } else {
            binding.tvFolderStatus.text = getString(R.string.backup_folder_not_set)
        }
    }

    private fun refreshData() {
        binding.swipeRefresh.isRefreshing = true
        val treeUri = prefs.backupTreeUri
        val includeSystem = prefs.showSystemApps

        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                if (currentTab == 0) {
                    repository.loadInstalledApps(includeSystem, treeUri)
                } else {
                    repository.loadArchivedBackups(treeUri)
                }
            }
            allItems = loaded
            applyFilterAndSort()
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun applyFilterAndSort() {
        val query = currentQuery.trim().lowercase()
        val filtered = if (query.isEmpty()) {
            allItems
        } else {
            allItems.filter {
                it.appName.lowercase().contains(query) ||
                        it.packageName.lowercase().contains(query)
            }
        }

        val sorted = when (prefs.sortOption) {
            SortOption.NAME_ASC -> filtered.sortedBy { it.appName.lowercase() }
            SortOption.NAME_DESC -> filtered.sortedByDescending { it.appName.lowercase() }
            SortOption.DATE_DESC -> filtered.sortedByDescending { it.timestamp }
            SortOption.DATE_ASC -> filtered.sortedBy { it.timestamp }
            SortOption.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
            SortOption.SIZE_ASC -> filtered.sortedBy { it.sizeBytes }
            SortOption.BACKUP_STATUS -> filtered.sortedWith(
                compareByDescending<AppItem> { it.isBackedUp }.thenBy { it.appName.lowercase() }
            )
        }

        adapter.submitList(sorted)
        binding.tvEmptyState.visibility = if (sorted.isEmpty()) View.VISIBLE else View.GONE
        binding.tvEmptyState.text = if (currentTab == 1 && !repository.hasValidTreePermission(prefs.backupTreeUri)) {
            "Select a Backup Folder first to view Archived Backups."
        } else {
            "No apps found"
        }
        updateSummaryBar()
    }

    private fun updateSummaryBar() {
        val total = adapter.getCurrentItems().size
        val selected = adapter.getSelectedItems().size
        binding.tvStatsSummary.text = "$total items | $selected selected | Sort: ${prefs.sortOption.displayName}"
    }

    private fun performBatchBackup(items: List<AppItem>) {
        val treeUri = prefs.backupTreeUri
        if (!repository.hasValidTreePermission(treeUri) || treeUri == null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Backup Folder Required")
                .setMessage("Please select a folder where 'App Backup' will store your APK files.")
                .setPositiveButton("Choose Folder") { _, _ ->
                    folderPickerLauncher.launch(null)
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        val keepOld = prefs.keepOldVersions
        binding.progressContainer.visibility = View.VISIBLE
        binding.progressBar.max = items.size
        binding.progressBar.progress = 0

        lifecycleScope.launch {
            var successCount = 0
            var failCount = 0
            var lastError = ""

            for ((index, app) in items.withIndex()) {
                binding.tvProgressLabel.text = "Backing up (${index + 1}/${items.size}): ${app.appName}..."
                binding.progressBar.progress = index + 1

                val result = withContext(Dispatchers.IO) {
                    repository.backupSingleApp(app, treeUri, keepOld)
                }
                if (result.isSuccess) {
                    successCount++
                } else {
                    failCount++
                    lastError = result.exceptionOrNull()?.message ?: "Unknown error"
                }
            }

            binding.progressContainer.visibility = View.GONE
            val msg = if (failCount == 0) {
                "Backed up $successCount app(s) successfully!"
            } else {
                "Backed up $successCount, failed $failCount ($lastError)"
            }
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
            refreshData()
        }
    }

    private fun performRestore(items: List<AppItem>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!packageManager.canRequestPackageInstalls()) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Install Permission Needed")
                    .setMessage("Allow 'Apps Backup Restore' to install apps from this source to restore your APK backups.")
                    .setPositiveButton("Grant Permission") { _, _ ->
                        val intent = Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:$packageName")
                        )
                        startActivity(intent)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                return
            }
        }

        lifecycleScope.launch {
            for (item in items) {
                val res = withContext(Dispatchers.IO) {
                    ApkInstallerHelper.installArchivedItem(this@MainActivity, item)
                }
                if (res.isFailure) {
                    Toast.makeText(
                        this@MainActivity,
                        "Restore error (${item.appName}): ${res.exceptionOrNull()?.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun shareItems(items: List<AppItem>) {
        binding.progressContainer.visibility = View.VISIBLE
        binding.tvProgressLabel.text = "Preparing files for sharing..."
        binding.progressBar.isIndeterminate = true

        lifecycleScope.launch {
            val intent = withContext(Dispatchers.IO) {
                repository.buildShareIntent(items)
            }
            binding.progressBar.isIndeterminate = false
            binding.progressContainer.visibility = View.GONE

            if (intent != null) {
                startActivity(Intent.createChooser(intent, "Share APK via"))
            } else {
                Toast.makeText(this@MainActivity, "Unable to prepare files for sharing", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun uninstallItems(items: List<AppItem>) {
        val userApps = items.filter { !it.isSystemApp }
        if (userApps.isEmpty()) {
            Toast.makeText(this, "System apps cannot be uninstalled directly.", Toast.LENGTH_SHORT).show()
            return
        }
        for (app in userApps) {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${app.packageName}")
            }
            uninstallLauncher.launch(intent)
        }
    }

    private fun confirmDeleteBackups(items: List<AppItem>) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Backups?")
            .setMessage("Delete ${items.size} selected backup(s) permanently from storage?")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    val count = withContext(Dispatchers.IO) {
                        var c = 0
                        for (item in items) {
                            if (repository.deleteArchivedItem(item)) c++
                        }
                        c
                    }
                    Toast.makeText(this@MainActivity, "Deleted $count backup(s)", Toast.LENGTH_SHORT).show()
                    refreshData()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSingleItemActionDialog(item: AppItem) {
        val options = if (!item.isArchivedItem) {
            arrayOf("Backup Now", "Share APK", "Uninstall App")
        } else {
            arrayOf("Restore / Install", "Share Backup", "Delete Backup")
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(item.appName)
            .setItems(options) { _, which ->
                if (!item.isArchivedItem) {
                    when (which) {
                        0 -> performBatchBackup(listOf(item))
                        1 -> shareItems(listOf(item))
                        2 -> uninstallItems(listOf(item))
                    }
                } else {
                    when (which) {
                        0 -> performRestore(listOf(item))
                        1 -> shareItems(listOf(item))
                        2 -> confirmDeleteBackups(listOf(item))
                    }
                }
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as? SearchView
        searchView?.queryHint = getString(R.string.search_hint)
        searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                currentQuery = query ?: ""
                applyFilterAndSort()
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                currentQuery = newText ?: ""
                applyFilterAndSort()
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_select_all -> {
                adapter.toggleSelectAll()
                true
            }
            R.id.action_refresh -> {
                refreshData()
                true
            }
            R.id.action_sort -> {
                showSortDialog()
                true
            }
            R.id.action_settings -> {
                showSettingsDialog()
                true
            }
            R.id.action_privacy -> {
                showPrivacyDialog()
                true
            }
            R.id.action_about -> {
                showAboutDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showSortDialog() {
        val options = SortOption.entries.toTypedArray()
        val labels = options.map { it.displayName }.toTypedArray()
        val currentIdx = options.indexOf(prefs.sortOption).coerceAtLeast(0)

        MaterialAlertDialogBuilder(this)
            .setTitle("Sort Applications")
            .setSingleChoiceItems(labels, currentIdx) { dialog, which ->
                prefs.sortOption = options[which]
                applyFilterAndSort()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSettingsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_settings, null)
        val switchKeepOld = view.findViewById<MaterialSwitch>(R.id.switchKeepOldVersions)
        val switchSystem = view.findViewById<MaterialSwitch>(R.id.switchShowSystemApps)
        val rgTheme = view.findViewById<RadioGroup>(R.id.rgTheme)

        switchKeepOld.isChecked = prefs.keepOldVersions
        switchSystem.isChecked = prefs.showSystemApps

        when (prefs.themeMode) {
            AppCompatDelegate.MODE_NIGHT_NO -> rgTheme.check(R.id.rbThemeLight)
            AppCompatDelegate.MODE_NIGHT_YES -> rgTheme.check(R.id.rbThemeDark)
            else -> rgTheme.check(R.id.rbThemeSystem)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Settings & Preferences")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                prefs.keepOldVersions = switchKeepOld.isChecked
                val sysChanged = prefs.showSystemApps != switchSystem.isChecked
                prefs.showSystemApps = switchSystem.isChecked

                val newTheme = when (rgTheme.checkedRadioButtonId) {
                    R.id.rbThemeLight -> AppCompatDelegate.MODE_NIGHT_NO
                    R.id.rbThemeDark -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
                if (prefs.themeMode != newTheme) {
                    prefs.themeMode = newTheme
                    AppCompatDelegate.setDefaultNightMode(newTheme)
                } else if (sysChanged && currentTab == 0) {
                    refreshData()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPrivacyDialog() {
        val message = """
            Apps Backup Restore - Privacy Policy
            Developer: Shahriar Rahman (SR Creation Farm)

            1. 100% Offline Operation:
            This application works completely offline on your device. No personal data, app lists, or APK files are ever uploaded to any external server.

            2. Storage Access:
            We only access the specific folder you explicitly grant via Android Storage Access Framework (SAF) to save and read your APK backups.

            3. App Package Visibility:
            QUERY_ALL_PACKAGES is used solely to display your installed applications so you can back them up locally.

            4. Zero Ads & Zero Trackers:
            This app contains no advertisements, analytics SDKs, or third-party tracking libraries.
        """.trimIndent()

        MaterialAlertDialogBuilder(this)
            .setTitle("Privacy Policy")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showAboutDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_about, null)
        view.findViewById<TextView>(R.id.tvAboutVersion).text =
            "Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"

        view.findViewById<MaterialButton>(R.id.btnYoutube).setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }
        view.findViewById<MaterialButton>(R.id.btnFacebook).setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }

        val dialog: AlertDialog = MaterialAlertDialogBuilder(this)
            .setView(view)
            .setPositiveButton("Close", null)
            .create()
        dialog.show()
    }

    private fun openExternalUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "No browser found to open link", Toast.LENGTH_SHORT).show()
        }
    }
}
