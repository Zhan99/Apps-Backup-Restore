package com.srcreationfarm.appsbackuprestore.util

import android.content.Context
import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import com.srcreationfarm.appsbackuprestore.model.SortOption

class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("sr_apps_backup_prefs", Context.MODE_PRIVATE)

    var backupTreeUri: Uri?
        get() = prefs.getString("backup_tree_uri", null)?.let { Uri.parse(it) }
        set(value) {
            prefs.edit().putString("backup_tree_uri", value?.toString()).apply()
        }

    var keepOldVersions: Boolean
        get() = prefs.getBoolean("keep_old_versions", false)
        set(value) {
            prefs.edit().putBoolean("keep_old_versions", value).apply()
        }

    var showSystemApps: Boolean
        get() = prefs.getBoolean("show_system_apps", false)
        set(value) {
            prefs.edit().putBoolean("show_system_apps", value).apply()
        }

    var themeMode: Int
        get() = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        set(value) {
            prefs.edit().putInt("theme_mode", value).apply()
        }

    var sortOption: SortOption
        get() {
            val name = prefs.getString("sort_option", SortOption.NAME_ASC.name) ?: SortOption.NAME_ASC.name
            return try {
                SortOption.valueOf(name)
            } catch (_: Exception) {
                SortOption.NAME_ASC
            }
        }
        set(value) {
            prefs.edit().putString("sort_option", value.name).apply()
        }
}
