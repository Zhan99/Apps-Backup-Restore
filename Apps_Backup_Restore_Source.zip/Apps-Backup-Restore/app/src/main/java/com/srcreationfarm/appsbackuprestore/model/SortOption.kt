package com.srcreationfarm.appsbackuprestore.model

enum class SortOption(val displayName: String) {
    NAME_ASC("Name (A to Z)"),
    NAME_DESC("Name (Z to A)"),
    DATE_DESC("Date (Newest First)"),
    DATE_ASC("Date (Oldest First)"),
    SIZE_DESC("Size (Largest First)"),
    SIZE_ASC("Size (Smallest First)"),
    BACKUP_STATUS("Backup Status (Backed Up First)")
}
