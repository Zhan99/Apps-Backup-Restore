package com.srcreationfarm.appsbackuprestore.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import com.srcreationfarm.appsbackuprestore.model.AppItem
import com.srcreationfarm.appsbackuprestore.receiver.InstallResultReceiver
import java.util.zip.ZipInputStream

object ApkInstallerHelper {

    fun installArchivedItem(context: Context, item: AppItem): Result<Unit> {
        return try {
            val splitUri = item.archiveSplitApksUri
            val singleApkUri = item.archiveApkUri

            if (splitUri != null) {
                installSplitApksFromUri(context, splitUri)
            } else if (singleApkUri != null) {
                installSingleApkFromUri(context, singleApkUri)
            } else {
                Result.failure(Exception("No valid backup file URI found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun installSingleApkFromUri(context: Context, apkUri: Uri): Result<Unit> {
        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(
            PackageInstaller.SessionParams.MODE_FULL_INSTALL
        )
        val sessionId = packageInstaller.createSession(params)
        val session = packageInstaller.openSession(sessionId)

        try {
            context.contentResolver.openInputStream(apkUri)?.use { input ->
                session.openWrite("base.apk", 0, -1).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                    session.fsync(output)
                }
            } ?: throw Exception("Cannot open APK backup stream")

            commitSession(context, session, sessionId)
            return Result.success(Unit)
        } catch (e: Exception) {
            session.abandon()
            return Result.failure(e)
        }
    }

    private fun installSplitApksFromUri(context: Context, apksUri: Uri): Result<Unit> {
        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(
            PackageInstaller.SessionParams.MODE_FULL_INSTALL
        )
        val sessionId = packageInstaller.createSession(params)
        val session = packageInstaller.openSession(sessionId)

        try {
            var apkCount = 0
            context.contentResolver.openInputStream(apksUri)?.use { rawInput ->
                ZipInputStream(rawInput).use { zipInput ->
                    var entry = zipInput.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        if (!entry.isDirectory && name.endsWith(".apk", ignoreCase = true)) {
                            val cleanEntryName = name.substringAfterLast("/")
                            session.openWrite(cleanEntryName, 0, -1).use { out ->
                                copyZipEntryStream(zipInput, out)
                                session.fsync(out)
                            }
                            apkCount++
                        }
                        zipInput.closeEntry()
                        entry = zipInput.nextEntry
                    }
                }
            } ?: throw Exception("Cannot open Split APK archive stream")

            if (apkCount == 0) {
                throw Exception("No APK entries found inside Split backup archive")
            }

            commitSession(context, session, sessionId)
            return Result.success(Unit)
        } catch (e: Exception) {
            session.abandon()
            return Result.failure(e)
        }
    }

    private fun copyZipEntryStream(zipIn: ZipInputStream, out: java.io.OutputStream) {
        val buffer = ByteArray(64 * 1024)
        var len: Int
        while (zipIn.read(buffer).also { len = it } > 0) {
            out.write(buffer, 0, len)
        }
    }

    private fun commitSession(
        context: Context,
        session: PackageInstaller.Session,
        sessionId: Int
    ) {
        val intent = Intent(context, InstallResultReceiver::class.java).apply {
            action = InstallResultReceiver.ACTION_INSTALL_STATUS
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            sessionId,
            intent,
            flags
        )
        session.commit(pendingIntent.intentSender)
        session.close()
    }
}
