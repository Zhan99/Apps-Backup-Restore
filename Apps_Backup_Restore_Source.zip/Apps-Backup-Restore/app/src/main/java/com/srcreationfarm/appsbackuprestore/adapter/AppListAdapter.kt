package com.srcreationfarm.appsbackuprestore.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.srcreationfarm.appsbackuprestore.databinding.ItemAppBinding
import com.srcreationfarm.appsbackuprestore.model.AppItem
import com.srcreationfarm.appsbackuprestore.util.FormatUtils

class AppListAdapter(
    private val onSelectionChanged: () -> Unit,
    private val onItemLongClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppListAdapter.AppViewHolder>() {

    private val items = mutableListOf<AppItem>()

    fun submitList(newItems: List<AppItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun getCurrentItems(): List<AppItem> = items

    fun getSelectedItems(): List<AppItem> = items.filter { it.isSelected }

    fun toggleSelectAll() {
        if (items.isEmpty()) return
        val allSelected = items.all { it.isSelected }
        val targetState = !allSelected
        items.forEach { it.isSelected = targetState }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class AppViewHolder(private val binding: ItemAppBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AppItem) {
            binding.tvAppName.text = item.appName
            binding.tvPackageName.text = item.packageName
            val sizeStr = FormatUtils.formatFileSize(item.sizeBytes)
            val dateStr = FormatUtils.formatDate(item.timestamp)
            binding.tvVersionSize.text = "v${item.versionName} | $sizeStr | $dateStr"

            if (item.icon != null) {
                binding.ivAppIcon.setImageDrawable(item.icon)
            } else {
                binding.ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon)
            }

            binding.tvBackupBadge.visibility =
                if (!item.isArchivedItem && item.isBackedUp) View.VISIBLE else View.GONE

            binding.tvSplitBadge.visibility =
                if (item.isSplitApk) View.VISIBLE else View.GONE

            binding.cbSelect.setOnCheckedChangeListener(null)
            binding.cbSelect.isChecked = item.isSelected

            binding.cbSelect.setOnCheckedChangeListener { _, isChecked ->
                item.isSelected = isChecked
                onSelectionChanged()
            }

            binding.root.setOnClickListener {
                item.isSelected = !item.isSelected
                binding.cbSelect.isChecked = item.isSelected
                onSelectionChanged()
            }

            binding.root.setOnLongClickListener {
                onItemLongClick(item)
                true
            }
        }
    }
}
