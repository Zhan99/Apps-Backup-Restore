# Error Prevention & Quality Control Log
**Project:** Apps Backup Restore (`com.srcreationfarm.appsbackuprestore`)  
**Developer:** Shahriar Rahman | **Brand:** SR Creation Farm

## Resolved & Prevented Issues

1. **Missing Android SDK `tools` Package**
   - **Root Cause:** Deprecated `tools` package passed to `sdkmanager`.
   - **Solution:** Uses `android-actions/setup-android@v4` with `"platform-tools"`, `"platforms;android-35"`, and `"build-tools;35.0.0"`.

2. **GitHub Workflow Auto ZIP Extraction**
   - **Root Cause:** Manual extraction required or wrong working directory when ZIP contains nested root folders.
   - **Solution:** `build.yml` automatically validates ZIP integrity (`unzip -t`), extracts into `extracted_source/`, locates `settings.gradle.kts`, and runs Gradle from that exact directory.

3. **WrongConstant URI Permission Lint Error**
   - **Root Cause:** Passing raw `data.flags` directly into `takePersistableUriPermission()`.
   - **Solution:** Explicitly passes `Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION` in `MainActivity.kt`.

4. **QUERY_ALL_PACKAGES Lint Error**
   - **Root Cause:** Android Lint flags `QUERY_ALL_PACKAGES` without justification.
   - **Solution:** Scoped `tools:ignore="QueryAllPackagesPermission"` on the permission declaration in `AndroidManifest.xml` since listing installed apps is the core function.

5. **Direct `.apk` vs Split `.apks` Compatibility**
   - **Root Cause:** Saving all apps as `.apks` prevented standard File Managers from showing icons and installing regular apps directly.
   - **Solution:** Saves intact Base `.apk` inside `App Backup/` for all apps, and creates a `STORED` `.apks` archive inside `App Backup/Split backups/` only when split APKs exist, avoiding duplicate entries in the Archived tab.

6. **PendingIntent Mutability Flag**
   - **Root Cause:** Android 12+ requires explicit mutability flags for `PackageInstaller` status `PendingIntent`.
   - **Solution:** Uses `PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE` on API 31+ (`Build.VERSION_CODES.S`).
